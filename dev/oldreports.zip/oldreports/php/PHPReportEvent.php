<?php
	define("REPORT_OPEN"	,0);
	define("REPORT_CLOSE",100);
	define("PAGE_OPEN"	,1);
	define("PAGE_CLOSE"	,101);
	define("GROUP_OPEN"	,2);
	define("GROUP_CLOSE"  ,102);
	define("PUT_DATA"		,3);
	define("PROCESS_DATA",4);
