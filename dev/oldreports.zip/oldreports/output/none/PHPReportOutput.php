<?php
	// MUST be in the include path
	require_once("PHPReportOutputObject.php");

	class PHPReportOutput extends PHPReportOutputObject {
		function run() {
			print "nothing to do";
		}
	}
?>
